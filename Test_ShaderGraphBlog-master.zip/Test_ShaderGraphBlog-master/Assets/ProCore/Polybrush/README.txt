Thanks for purchasing Polybrush!

Online documentation (including a Quick Start guide) is available here:

procore3d.com/docs/polybrush

Or you can read the PDF manual located in:

Assets/ProCore/Polybrush/Documentation/manual.pdf

To gain access to the Github repository for Polybrush, send an email to contact@procore3d.com with your:

- Invoice number
- Github account name

This repository includes the latest alpha and development builds, and access to the issue tracker.
